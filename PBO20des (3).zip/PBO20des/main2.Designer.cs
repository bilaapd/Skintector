﻿namespace PBO20des
{
    partial class main2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Essencial_Acid = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Skincarename = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Glycerin = new System.Windows.Forms.CheckBox();
            this.Kaolin_Clay = new System.Windows.Forms.CheckBox();
            this.Hyaluronic_Acid = new System.Windows.Forms.CheckBox();
            this.SLS = new System.Windows.Forms.CheckBox();
            this.ALS = new System.Windows.Forms.CheckBox();
            this.AHA = new System.Windows.Forms.CheckBox();
            this.BHA = new System.Windows.Forms.CheckBox();
            this.Retinoid = new System.Windows.Forms.CheckBox();
            this.Chamomile = new System.Windows.Forms.CheckBox();
            this.Ferulic_Acid = new System.Windows.Forms.CheckBox();
            this.Niacinamide = new System.Windows.Forms.CheckBox();
            this.Tea_Tree = new System.Windows.Forms.CheckBox();
            this.Mandelic_Acid = new System.Windows.Forms.CheckBox();
            this.Salysilic_Acid = new System.Windows.Forms.CheckBox();
            this.Emollient = new System.Windows.Forms.CheckBox();
            this.Ceramide = new System.Windows.Forms.CheckBox();
            this.Allantoin = new System.Windows.Forms.CheckBox();
            this.Paraben = new System.Windows.Forms.CheckBox();
            this.Sulfate = new System.Windows.Forms.CheckBox();
            this.Butyl = new System.Windows.Forms.CheckBox();
            this.Isopropyl = new System.Windows.Forms.CheckBox();
            this.Alcohol_Denat = new System.Windows.Forms.CheckBox();
            this.Benzoyl = new System.Windows.Forms.CheckBox();
            this.Vit_C = new System.Windows.Forms.CheckBox();
            this.Glycolic_Acid = new System.Windows.Forms.CheckBox();
            this.Lactic_Acid = new System.Windows.Forms.CheckBox();
            this.Done_test = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.resultboxgood = new System.Windows.Forms.TextBox();
            this.resultboxbad = new System.Windows.Forms.TextBox();
            this.gdrybox = new System.Windows.Forms.TextBox();
            this.goilybox = new System.Windows.Forms.TextBox();
            this.gsensibox = new System.Windows.Forms.TextBox();
            this.gacnebox = new System.Windows.Forms.TextBox();
            this.gcombibox = new System.Windows.Forms.TextBox();
            this.bcombibox = new System.Windows.Forms.TextBox();
            this.bacnebox = new System.Windows.Forms.TextBox();
            this.bsensibox = new System.Windows.Forms.TextBox();
            this.boilybox = new System.Windows.Forms.TextBox();
            this.bdrybox = new System.Windows.Forms.TextBox();
            this.reset_btn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Papyrus", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "SkinTector";
            // 
            // Essencial_Acid
            // 
            this.Essencial_Acid.AutoSize = true;
            this.Essencial_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Essencial_Acid.Location = new System.Drawing.Point(22, 167);
            this.Essencial_Acid.Name = "Essencial_Acid";
            this.Essencial_Acid.Size = new System.Drawing.Size(153, 26);
            this.Essencial_Acid.TabIndex = 1;
            this.Essencial_Acid.Text = "Essencial Acid";
            this.Essencial_Acid.UseVisualStyleBackColor = true;
            this.Essencial_Acid.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(528, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "2. Checked the box if the ingredients belongs to ur skincare!";
            // 
            // Skincarename
            // 
            this.Skincarename.Location = new System.Drawing.Point(20, 97);
            this.Skincarename.Multiline = true;
            this.Skincarename.Name = "Skincarename";
            this.Skincarename.Size = new System.Drawing.Size(524, 37);
            this.Skincarename.TabIndex = 3;
            this.Skincarename.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(330, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "1. Write your skincare\'s name below!";
            // 
            // Glycerin
            // 
            this.Glycerin.AutoSize = true;
            this.Glycerin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Glycerin.Location = new System.Drawing.Point(22, 199);
            this.Glycerin.Name = "Glycerin";
            this.Glycerin.Size = new System.Drawing.Size(102, 26);
            this.Glycerin.TabIndex = 5;
            this.Glycerin.Text = "Glycerin";
            this.Glycerin.UseVisualStyleBackColor = true;
            this.Glycerin.CheckedChanged += new System.EventHandler(this.Glycerin_CheckedChanged);
            // 
            // Kaolin_Clay
            // 
            this.Kaolin_Clay.AutoSize = true;
            this.Kaolin_Clay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Kaolin_Clay.Location = new System.Drawing.Point(22, 262);
            this.Kaolin_Clay.Name = "Kaolin_Clay";
            this.Kaolin_Clay.Size = new System.Drawing.Size(127, 26);
            this.Kaolin_Clay.TabIndex = 7;
            this.Kaolin_Clay.Text = "Kaolin Clay";
            this.Kaolin_Clay.UseVisualStyleBackColor = true;
            this.Kaolin_Clay.CheckedChanged += new System.EventHandler(this.Kaolin_Clay_CheckedChanged);
            // 
            // Hyaluronic_Acid
            // 
            this.Hyaluronic_Acid.AutoSize = true;
            this.Hyaluronic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hyaluronic_Acid.Location = new System.Drawing.Point(22, 230);
            this.Hyaluronic_Acid.Name = "Hyaluronic_Acid";
            this.Hyaluronic_Acid.Size = new System.Drawing.Size(161, 26);
            this.Hyaluronic_Acid.TabIndex = 6;
            this.Hyaluronic_Acid.Text = "Hyaluronic Acid";
            this.Hyaluronic_Acid.UseVisualStyleBackColor = true;
            this.Hyaluronic_Acid.CheckedChanged += new System.EventHandler(this.Hyaluronic_Acid_CheckedChanged);
            // 
            // SLS
            // 
            this.SLS.AutoSize = true;
            this.SLS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SLS.Location = new System.Drawing.Point(22, 389);
            this.SLS.Name = "SLS";
            this.SLS.Size = new System.Drawing.Size(262, 26);
            this.SLS.TabIndex = 11;
            this.SLS.Text = "Sodium Lauryl Sulfate (SLS)";
            this.SLS.UseVisualStyleBackColor = true;
            this.SLS.CheckedChanged += new System.EventHandler(this.SLS_CheckedChanged);
            // 
            // ALS
            // 
            this.ALS.AutoSize = true;
            this.ALS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ALS.Location = new System.Drawing.Point(22, 357);
            this.ALS.Name = "ALS";
            this.ALS.Size = new System.Drawing.Size(290, 26);
            this.ALS.TabIndex = 10;
            this.ALS.Text = "Ammonium Lauryl Sulfate (ALS)";
            this.ALS.UseVisualStyleBackColor = true;
            this.ALS.CheckedChanged += new System.EventHandler(this.ALS_CheckedChanged);
            // 
            // AHA
            // 
            this.AHA.AutoSize = true;
            this.AHA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AHA.Location = new System.Drawing.Point(22, 326);
            this.AHA.Name = "AHA";
            this.AHA.Size = new System.Drawing.Size(247, 26);
            this.AHA.TabIndex = 9;
            this.AHA.Text = "Alpha Hydroxy Acid (AHA)";
            this.AHA.UseVisualStyleBackColor = true;
            this.AHA.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // BHA
            // 
            this.BHA.AutoSize = true;
            this.BHA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BHA.Location = new System.Drawing.Point(22, 294);
            this.BHA.Name = "BHA";
            this.BHA.Size = new System.Drawing.Size(233, 26);
            this.BHA.TabIndex = 8;
            this.BHA.Text = "Beta Hidroxy Acid (BHA)";
            this.BHA.UseVisualStyleBackColor = true;
            this.BHA.CheckedChanged += new System.EventHandler(this.BHA_CheckedChanged);
            // 
            // Retinoid
            // 
            this.Retinoid.AutoSize = true;
            this.Retinoid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Retinoid.Location = new System.Drawing.Point(347, 389);
            this.Retinoid.Name = "Retinoid";
            this.Retinoid.Size = new System.Drawing.Size(102, 26);
            this.Retinoid.TabIndex = 19;
            this.Retinoid.Text = "Retinoid";
            this.Retinoid.UseVisualStyleBackColor = true;
            this.Retinoid.CheckedChanged += new System.EventHandler(this.Retinoid_CheckedChanged);
            // 
            // Chamomile
            // 
            this.Chamomile.AutoSize = true;
            this.Chamomile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chamomile.Location = new System.Drawing.Point(347, 357);
            this.Chamomile.Name = "Chamomile";
            this.Chamomile.Size = new System.Drawing.Size(125, 26);
            this.Chamomile.TabIndex = 18;
            this.Chamomile.Text = "Chamomile";
            this.Chamomile.UseVisualStyleBackColor = true;
            this.Chamomile.CheckedChanged += new System.EventHandler(this.Chamomile_CheckedChanged);
            // 
            // Ferulic_Acid
            // 
            this.Ferulic_Acid.AutoSize = true;
            this.Ferulic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ferulic_Acid.Location = new System.Drawing.Point(347, 326);
            this.Ferulic_Acid.Name = "Ferulic_Acid";
            this.Ferulic_Acid.Size = new System.Drawing.Size(130, 26);
            this.Ferulic_Acid.TabIndex = 17;
            this.Ferulic_Acid.Text = "Ferulic Acid";
            this.Ferulic_Acid.UseVisualStyleBackColor = true;
            this.Ferulic_Acid.CheckedChanged += new System.EventHandler(this.Ferulic_Acid_CheckedChanged);
            // 
            // Niacinamide
            // 
            this.Niacinamide.AutoSize = true;
            this.Niacinamide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Niacinamide.Location = new System.Drawing.Point(347, 294);
            this.Niacinamide.Name = "Niacinamide";
            this.Niacinamide.Size = new System.Drawing.Size(134, 26);
            this.Niacinamide.TabIndex = 16;
            this.Niacinamide.Text = "Niacinamide";
            this.Niacinamide.UseVisualStyleBackColor = true;
            this.Niacinamide.CheckedChanged += new System.EventHandler(this.Niacinamide_CheckedChanged);
            // 
            // Tea_Tree
            // 
            this.Tea_Tree.AutoSize = true;
            this.Tea_Tree.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tea_Tree.Location = new System.Drawing.Point(347, 262);
            this.Tea_Tree.Name = "Tea_Tree";
            this.Tea_Tree.Size = new System.Drawing.Size(116, 26);
            this.Tea_Tree.TabIndex = 15;
            this.Tea_Tree.Text = "Tea Tree ";
            this.Tea_Tree.UseVisualStyleBackColor = true;
            this.Tea_Tree.CheckedChanged += new System.EventHandler(this.Tea_Tree_CheckedChanged);
            // 
            // Mandelic_Acid
            // 
            this.Mandelic_Acid.AutoSize = true;
            this.Mandelic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mandelic_Acid.Location = new System.Drawing.Point(347, 230);
            this.Mandelic_Acid.Name = "Mandelic_Acid";
            this.Mandelic_Acid.Size = new System.Drawing.Size(147, 26);
            this.Mandelic_Acid.TabIndex = 14;
            this.Mandelic_Acid.Text = "Mandelic Acid";
            this.Mandelic_Acid.UseVisualStyleBackColor = true;
            this.Mandelic_Acid.CheckedChanged += new System.EventHandler(this.Mandelic_Acid_CheckedChanged);
            // 
            // Salysilic_Acid
            // 
            this.Salysilic_Acid.AutoSize = true;
            this.Salysilic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salysilic_Acid.Location = new System.Drawing.Point(347, 199);
            this.Salysilic_Acid.Name = "Salysilic_Acid";
            this.Salysilic_Acid.Size = new System.Drawing.Size(141, 26);
            this.Salysilic_Acid.TabIndex = 13;
            this.Salysilic_Acid.Text = "Salysilic Acid";
            this.Salysilic_Acid.UseVisualStyleBackColor = true;
            this.Salysilic_Acid.CheckedChanged += new System.EventHandler(this.Salysilic_Acid_CheckedChanged);
            // 
            // Emollient
            // 
            this.Emollient.AutoSize = true;
            this.Emollient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emollient.Location = new System.Drawing.Point(347, 167);
            this.Emollient.Name = "Emollient";
            this.Emollient.Size = new System.Drawing.Size(114, 26);
            this.Emollient.TabIndex = 12;
            this.Emollient.Text = "Emollient ";
            this.Emollient.UseVisualStyleBackColor = true;
            this.Emollient.CheckedChanged += new System.EventHandler(this.Emollient_CheckedChanged);
            // 
            // Ceramide
            // 
            this.Ceramide.AutoSize = true;
            this.Ceramide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ceramide.Location = new System.Drawing.Point(558, 389);
            this.Ceramide.Name = "Ceramide";
            this.Ceramide.Size = new System.Drawing.Size(118, 26);
            this.Ceramide.TabIndex = 27;
            this.Ceramide.Text = "Ceramide ";
            this.Ceramide.UseVisualStyleBackColor = true;
            this.Ceramide.CheckedChanged += new System.EventHandler(this.Ceramide_CheckedChanged);
            // 
            // Allantoin
            // 
            this.Allantoin.AutoSize = true;
            this.Allantoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Allantoin.Location = new System.Drawing.Point(558, 357);
            this.Allantoin.Name = "Allantoin";
            this.Allantoin.Size = new System.Drawing.Size(105, 26);
            this.Allantoin.TabIndex = 26;
            this.Allantoin.Text = "Allantoin";
            this.Allantoin.UseVisualStyleBackColor = true;
            this.Allantoin.CheckedChanged += new System.EventHandler(this.Allantoin_CheckedChanged);
            // 
            // Paraben
            // 
            this.Paraben.AutoSize = true;
            this.Paraben.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Paraben.Location = new System.Drawing.Point(558, 326);
            this.Paraben.Name = "Paraben";
            this.Paraben.Size = new System.Drawing.Size(104, 26);
            this.Paraben.TabIndex = 25;
            this.Paraben.Text = "Paraben";
            this.Paraben.UseVisualStyleBackColor = true;
            this.Paraben.CheckedChanged += new System.EventHandler(this.Paraben_CheckedChanged);
            // 
            // Sulfate
            // 
            this.Sulfate.AutoSize = true;
            this.Sulfate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sulfate.Location = new System.Drawing.Point(558, 294);
            this.Sulfate.Name = "Sulfate";
            this.Sulfate.Size = new System.Drawing.Size(92, 26);
            this.Sulfate.TabIndex = 24;
            this.Sulfate.Text = "Sulfate";
            this.Sulfate.UseVisualStyleBackColor = true;
            this.Sulfate.CheckedChanged += new System.EventHandler(this.Sulfate_CheckedChanged);
            // 
            // Butyl
            // 
            this.Butyl.AutoSize = true;
            this.Butyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Butyl.Location = new System.Drawing.Point(558, 262);
            this.Butyl.Name = "Butyl";
            this.Butyl.Size = new System.Drawing.Size(149, 26);
            this.Butyl.TabIndex = 23;
            this.Butyl.Text = "Butyl Stearate";
            this.Butyl.UseVisualStyleBackColor = true;
            this.Butyl.CheckedChanged += new System.EventHandler(this.Butyl_CheckedChanged);
            // 
            // Isopropyl
            // 
            this.Isopropyl.AutoSize = true;
            this.Isopropyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Isopropyl.Location = new System.Drawing.Point(558, 230);
            this.Isopropyl.Name = "Isopropyl";
            this.Isopropyl.Size = new System.Drawing.Size(185, 26);
            this.Isopropyl.TabIndex = 22;
            this.Isopropyl.Text = "Isopropyl Myristate";
            this.Isopropyl.UseVisualStyleBackColor = true;
            this.Isopropyl.CheckedChanged += new System.EventHandler(this.Isopropyl_CheckedChanged);
            // 
            // Alcohol_Denat
            // 
            this.Alcohol_Denat.AutoSize = true;
            this.Alcohol_Denat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alcohol_Denat.Location = new System.Drawing.Point(558, 199);
            this.Alcohol_Denat.Name = "Alcohol_Denat";
            this.Alcohol_Denat.Size = new System.Drawing.Size(148, 26);
            this.Alcohol_Denat.TabIndex = 21;
            this.Alcohol_Denat.Text = "Alcohol Denat";
            this.Alcohol_Denat.UseVisualStyleBackColor = true;
            this.Alcohol_Denat.CheckedChanged += new System.EventHandler(this.Alcohol_Denat_CheckedChanged);
            // 
            // Benzoyl
            // 
            this.Benzoyl.AutoSize = true;
            this.Benzoyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Benzoyl.Location = new System.Drawing.Point(558, 167);
            this.Benzoyl.Name = "Benzoyl";
            this.Benzoyl.Size = new System.Drawing.Size(175, 26);
            this.Benzoyl.TabIndex = 20;
            this.Benzoyl.Text = "Benzoyl Peroxide";
            this.Benzoyl.UseVisualStyleBackColor = true;
            this.Benzoyl.CheckedChanged += new System.EventHandler(this.Benzoyl_CheckedChanged);
            // 
            // Vit_C
            // 
            this.Vit_C.AutoSize = true;
            this.Vit_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vit_C.Location = new System.Drawing.Point(22, 418);
            this.Vit_C.Name = "Vit_C";
            this.Vit_C.Size = new System.Drawing.Size(113, 26);
            this.Vit_C.TabIndex = 29;
            this.Vit_C.Text = "Vitamin C";
            this.Vit_C.UseVisualStyleBackColor = true;
            this.Vit_C.CheckedChanged += new System.EventHandler(this.Vit_C_CheckedChanged);
            // 
            // Glycolic_Acid
            // 
            this.Glycolic_Acid.AutoSize = true;
            this.Glycolic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Glycolic_Acid.Location = new System.Drawing.Point(347, 418);
            this.Glycolic_Acid.Name = "Glycolic_Acid";
            this.Glycolic_Acid.Size = new System.Drawing.Size(139, 26);
            this.Glycolic_Acid.TabIndex = 30;
            this.Glycolic_Acid.Text = "Glycolic Acid";
            this.Glycolic_Acid.UseVisualStyleBackColor = true;
            this.Glycolic_Acid.CheckedChanged += new System.EventHandler(this.Glycolic_Acid_CheckedChanged);
            // 
            // Lactic_Acid
            // 
            this.Lactic_Acid.AutoSize = true;
            this.Lactic_Acid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lactic_Acid.Location = new System.Drawing.Point(558, 418);
            this.Lactic_Acid.Name = "Lactic_Acid";
            this.Lactic_Acid.Size = new System.Drawing.Size(123, 26);
            this.Lactic_Acid.TabIndex = 31;
            this.Lactic_Acid.Text = "Lactic Acid";
            this.Lactic_Acid.UseVisualStyleBackColor = true;
            this.Lactic_Acid.CheckedChanged += new System.EventHandler(this.Lactic_Acid_CheckedChanged);
            // 
            // Done_test
            // 
            this.Done_test.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Done_test.Location = new System.Drawing.Point(42, 478);
            this.Done_test.Name = "Done_test";
            this.Done_test.Size = new System.Drawing.Size(116, 48);
            this.Done_test.TabIndex = 32;
            this.Done_test.Text = "Done!";
            this.Done_test.UseVisualStyleBackColor = true;
            this.Done_test.Click += new System.EventHandler(this.Done_test_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(734, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 29);
            this.label4.TabIndex = 33;
            this.label4.Text = "x";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 450);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(360, 25);
            this.label5.TabIndex = 34;
            this.label5.Text = "3. If you\'re done, press the button below.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 529);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 25);
            this.label6.TabIndex = 35;
            this.label6.Text = "4. Result";
            // 
            // resultboxgood
            // 
            this.resultboxgood.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultboxgood.Location = new System.Drawing.Point(42, 557);
            this.resultboxgood.Multiline = true;
            this.resultboxgood.Name = "resultboxgood";
            this.resultboxgood.Size = new System.Drawing.Size(691, 48);
            this.resultboxgood.TabIndex = 36;
            this.resultboxgood.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // resultboxbad
            // 
            this.resultboxbad.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultboxbad.Location = new System.Drawing.Point(42, 670);
            this.resultboxbad.Multiline = true;
            this.resultboxbad.Name = "resultboxbad";
            this.resultboxbad.Size = new System.Drawing.Size(691, 48);
            this.resultboxbad.TabIndex = 37;
            // 
            // gdrybox
            // 
            this.gdrybox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gdrybox.Location = new System.Drawing.Point(42, 611);
            this.gdrybox.Multiline = true;
            this.gdrybox.Name = "gdrybox";
            this.gdrybox.Size = new System.Drawing.Size(82, 40);
            this.gdrybox.TabIndex = 38;
            this.gdrybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // goilybox
            // 
            this.goilybox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goilybox.Location = new System.Drawing.Point(143, 611);
            this.goilybox.Multiline = true;
            this.goilybox.Name = "goilybox";
            this.goilybox.Size = new System.Drawing.Size(88, 40);
            this.goilybox.TabIndex = 39;
            this.goilybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.goilybox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // gsensibox
            // 
            this.gsensibox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gsensibox.Location = new System.Drawing.Point(250, 611);
            this.gsensibox.Multiline = true;
            this.gsensibox.Name = "gsensibox";
            this.gsensibox.Size = new System.Drawing.Size(146, 40);
            this.gsensibox.TabIndex = 40;
            this.gsensibox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gacnebox
            // 
            this.gacnebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gacnebox.Location = new System.Drawing.Point(416, 611);
            this.gacnebox.Multiline = true;
            this.gacnebox.Name = "gacnebox";
            this.gacnebox.Size = new System.Drawing.Size(99, 40);
            this.gacnebox.TabIndex = 41;
            this.gacnebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gcombibox
            // 
            this.gcombibox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gcombibox.Location = new System.Drawing.Point(534, 611);
            this.gcombibox.Multiline = true;
            this.gcombibox.Name = "gcombibox";
            this.gcombibox.Size = new System.Drawing.Size(199, 40);
            this.gcombibox.TabIndex = 42;
            this.gcombibox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bcombibox
            // 
            this.bcombibox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bcombibox.Location = new System.Drawing.Point(534, 724);
            this.bcombibox.Multiline = true;
            this.bcombibox.Name = "bcombibox";
            this.bcombibox.Size = new System.Drawing.Size(199, 40);
            this.bcombibox.TabIndex = 47;
            this.bcombibox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bacnebox
            // 
            this.bacnebox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bacnebox.Location = new System.Drawing.Point(416, 724);
            this.bacnebox.Multiline = true;
            this.bacnebox.Name = "bacnebox";
            this.bacnebox.Size = new System.Drawing.Size(99, 40);
            this.bacnebox.TabIndex = 46;
            this.bacnebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bsensibox
            // 
            this.bsensibox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bsensibox.Location = new System.Drawing.Point(250, 724);
            this.bsensibox.Multiline = true;
            this.bsensibox.Name = "bsensibox";
            this.bsensibox.Size = new System.Drawing.Size(146, 40);
            this.bsensibox.TabIndex = 45;
            this.bsensibox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // boilybox
            // 
            this.boilybox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.boilybox.Location = new System.Drawing.Point(143, 724);
            this.boilybox.Multiline = true;
            this.boilybox.Name = "boilybox";
            this.boilybox.Size = new System.Drawing.Size(88, 40);
            this.boilybox.TabIndex = 44;
            this.boilybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bdrybox
            // 
            this.bdrybox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdrybox.Location = new System.Drawing.Point(42, 724);
            this.bdrybox.Multiline = true;
            this.bdrybox.Name = "bdrybox";
            this.bdrybox.Size = new System.Drawing.Size(82, 40);
            this.bdrybox.TabIndex = 43;
            this.bdrybox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // reset_btn
            // 
            this.reset_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reset_btn.Location = new System.Drawing.Point(42, 795);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(112, 48);
            this.reset_btn.TabIndex = 48;
            this.reset_btn.Text = "Reset";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 767);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(732, 25);
            this.label7.TabIndex = 49;
            this.label7.Text = "5. If you want to try to check another skincare, you can press the reset button b" +
    "elow.";
            // 
            // main2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(771, 860);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.reset_btn);
            this.Controls.Add(this.bcombibox);
            this.Controls.Add(this.bacnebox);
            this.Controls.Add(this.bsensibox);
            this.Controls.Add(this.boilybox);
            this.Controls.Add(this.bdrybox);
            this.Controls.Add(this.gcombibox);
            this.Controls.Add(this.gacnebox);
            this.Controls.Add(this.gsensibox);
            this.Controls.Add(this.goilybox);
            this.Controls.Add(this.gdrybox);
            this.Controls.Add(this.resultboxbad);
            this.Controls.Add(this.resultboxgood);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Done_test);
            this.Controls.Add(this.Lactic_Acid);
            this.Controls.Add(this.Glycolic_Acid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Vit_C);
            this.Controls.Add(this.Ceramide);
            this.Controls.Add(this.Allantoin);
            this.Controls.Add(this.Paraben);
            this.Controls.Add(this.Sulfate);
            this.Controls.Add(this.Butyl);
            this.Controls.Add(this.Isopropyl);
            this.Controls.Add(this.Alcohol_Denat);
            this.Controls.Add(this.Benzoyl);
            this.Controls.Add(this.Retinoid);
            this.Controls.Add(this.Chamomile);
            this.Controls.Add(this.Ferulic_Acid);
            this.Controls.Add(this.Niacinamide);
            this.Controls.Add(this.Tea_Tree);
            this.Controls.Add(this.Mandelic_Acid);
            this.Controls.Add(this.Salysilic_Acid);
            this.Controls.Add(this.Emollient);
            this.Controls.Add(this.SLS);
            this.Controls.Add(this.ALS);
            this.Controls.Add(this.AHA);
            this.Controls.Add(this.BHA);
            this.Controls.Add(this.Kaolin_Clay);
            this.Controls.Add(this.Hyaluronic_Acid);
            this.Controls.Add(this.Glycerin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Skincarename);
            this.Controls.Add(this.Essencial_Acid);
            this.Controls.Add(this.label1);
            this.Name = "main2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox Essencial_Acid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Skincarename;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox Glycerin;
        private System.Windows.Forms.CheckBox Kaolin_Clay;
        private System.Windows.Forms.CheckBox Hyaluronic_Acid;
        private System.Windows.Forms.CheckBox SLS;
        private System.Windows.Forms.CheckBox ALS;
        private System.Windows.Forms.CheckBox AHA;
        private System.Windows.Forms.CheckBox BHA;
        private System.Windows.Forms.CheckBox Retinoid;
        private System.Windows.Forms.CheckBox Chamomile;
        private System.Windows.Forms.CheckBox Ferulic_Acid;
        private System.Windows.Forms.CheckBox Niacinamide;
        private System.Windows.Forms.CheckBox Tea_Tree;
        private System.Windows.Forms.CheckBox Mandelic_Acid;
        private System.Windows.Forms.CheckBox Salysilic_Acid;
        private System.Windows.Forms.CheckBox Emollient;
        private System.Windows.Forms.CheckBox Ceramide;
        private System.Windows.Forms.CheckBox Allantoin;
        private System.Windows.Forms.CheckBox Paraben;
        private System.Windows.Forms.CheckBox Sulfate;
        private System.Windows.Forms.CheckBox Butyl;
        private System.Windows.Forms.CheckBox Isopropyl;
        private System.Windows.Forms.CheckBox Alcohol_Denat;
        private System.Windows.Forms.CheckBox Benzoyl;
        private System.Windows.Forms.CheckBox Vit_C;
        private System.Windows.Forms.CheckBox Glycolic_Acid;
        private System.Windows.Forms.CheckBox Lactic_Acid;
        private System.Windows.Forms.Button Done_test;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox resultboxgood;
        private System.Windows.Forms.TextBox resultboxbad;
        private System.Windows.Forms.TextBox gdrybox;
        private System.Windows.Forms.TextBox goilybox;
        private System.Windows.Forms.TextBox gsensibox;
        private System.Windows.Forms.TextBox gacnebox;
        private System.Windows.Forms.TextBox gcombibox;
        private System.Windows.Forms.TextBox bcombibox;
        private System.Windows.Forms.TextBox bacnebox;
        private System.Windows.Forms.TextBox bsensibox;
        private System.Windows.Forms.TextBox boilybox;
        private System.Windows.Forms.TextBox bdrybox;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.Label label7;
    }
}